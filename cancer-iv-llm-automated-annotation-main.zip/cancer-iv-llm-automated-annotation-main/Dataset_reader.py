
# This file is used to read the dataset from the jsonl file

import json                                      #導入json模組，用於處理JSON格式的數據


class DatasetReader:                             #定義DatasetReader類，負責讀取和管理數據集
    def __init__(self, dataset_path):            
        self.dataset_path = dataset_path         #設置數據集文件的路徑      
        self.dataset = [] # [ [contents,labels] ] 初始化數據集列表，存儲[content, label]的列表
        
        jsonl_lines = None                                          #初始化jsonl_lines
        with open(self.dataset_path, 'r', encoding='utf-8') as f:   #打開JSONL文件，讀取所有行
            jsonl_lines = f.readlines()                             #讀取所有行
        for line in jsonl_lines:                                    #逐行處理JSONL文件，解析JSON數據並添加到數據集中
            data = json.loads(line)                                 #解析JSON數據
            self.dataset.append([data['content'], data['label']])   #將content和label添加到數據集中
            
    def __len__(self):                       #定義__len__方法，返回數據集的長度
        return len(self.dataset)             #返回數據集的長度
    def get_dataset(self):                   #獲取數據集
        return self.dataset                  #返回整個數據集
    
    def __getitem__(self, idx):                      #根據索引返回特定的數據條目
        return self.dataset[idx]                     #返回數據條目
    def __iter__(self):                              #使DatasetReader 對象可迭代
        return iter(self.dataset)                    #返回數據集的迭代器
    def get_content(self, idx):                      #根據索引返回特定數據條目的內容 
        return self.dataset[idx][0]                  #返回數據條目的內容 
    def get_label(self, idx):                        #根據索引返回特定數據條目的標籤
        return self.dataset[idx][1]                  #返回數據條目的標籤
    def get_all_contents(self):                      #獲取數據集中所有內容
        return [data[0] for data in self.dataset]    #返回數據集中所有內容
    
    
        
        
        
if __name__ == '__main__':                                     #測試部分：創建DatasetReader對象並進行一些操作
    dataset_reader = DatasetReader('./.output/dataset.jsonl')
    
    '''
    r = dataset_reader.get_dataset()             
    for i in range(50, 60):
        print(r[i])                   
    # print(r)                        
    
    '''
    s = 0                              #起始索引
    e = 100                            #結束索引
    
    print(len(dataset_reader))                         #輸出數據集的長度
    all_contents = dataset_reader.get_all_contents()   #獲取數據中所有內容
    
    for i in range(s, e):                              #遍歷指定範圍內的數據條目
        if dataset_reader.get_label(i) != 'NULL':      #若標籤不是NULL，則輸出內容和標籤
        
            print('------------------------------------')    #分隔線
            print(all_contents[i])                           #輸出內容
            print('#####')                                   #分隔線
            print(dataset_reader.get_label(i))               #輸出標籤
            print('------------------------------------')    #分隔線
        

    