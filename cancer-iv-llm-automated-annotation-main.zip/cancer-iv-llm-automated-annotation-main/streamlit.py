import streamlit as st
import os
import shutil
import numpy as np
from main import main
import time
from PIL import Image

if 'snow_shown' not in st.session_state:                 #若snow_shown不在st.session_state中
    st.session_state.snow_shown = False                  #將snow_shown設為False

# 如果没有下过雪，则显示下雪效果并将状态改为已下雪
if not st.session_state.snow_shown:                      #若snow_shown為False
    st.snow()                                            #顯示下雪效果
    st.session_state.snow_shown = True                   #將snow_shown設為True

# 顯示本地圖片

img_path = "LLM.jpg"
img = open(img_path, 'rb').read()
st.image(img, caption='LLM', use_column_width=True)

st.header(":rainbow[LLM自動標記程式]")                    #顯示標題 
#只能在cmd輸入 : streamlit run C:\Users\User\Desktop\cancer-iv-llm-automated-annotation-main\streamlit.py

uploaded_file = st.file_uploader('請將文件拖曳到下框內')     #上傳檔案

if uploaded_file is not None:                         #若檔案不為空，則執行以下程式碼

    file_name = uploaded_file.name                    #取得檔案名稱

    os.makedirs("./uploads", exist_ok=True)           #建立uploads資料夾
    save_path = os.path.join("./uploads", file_name)  #將檔案路徑存到save_path，路徑為uploads資料夾+檔案名稱
    
    # Save the file to disk
    with open(save_path, "wb") as f:                  #以二進位制寫入檔案
        f.write(uploaded_file.getbuffer())            #將檔案寫入到save_path

if (st.button('執行xml檔案') ):                        #若按下執行xml檔案按鈕
        res =  main(save_path)                        #執行main函數，將save_path傳入
        st.write(res)                                 #顯示res
        # progress_text = "檔案正在載入中..."          #進度條文字   
        with st.spinner('檔案正在載入中...'):          #顯示檔案正在載入中    
            my_bar = st.progress(0)                   #顯示進度條
            time.sleep(5)


        progress_text = ":+1:檔案正在標記中..."        #進度條文字
        for percent_complete in range(100):           #進度條
            time.sleep(0.01)                          #每0.01秒執行一次
            my_bar.progress(percent_complete + 1, text=progress_text + f'進度 {percent_complete+1} %')  #進度條顯示進度
        time.sleep(1)                                 #每1秒執行一次
        my_bar.empty()                                #清空進度條
        st.success('恭喜完成!', icon='🎉')                        
        st.balloons()                                 #顯示氣球
        with open(res, "rb") as file:                 #以二進位制讀取檔案
            res_b = file.read()                       #讀取檔案
        
        st.download_button('下載xml檔案', res_b,file_name=res )   #將文字下載下來，存成xml檔
        st.toast(':rainbow[可以下載]', icon='💯')        



def delete_files_in_directory(directory):             #刪除資料夾中的檔案
    # 取得目錄中所有的檔案列表
    file_list = os.listdir(directory)                 #將directory中的檔案存到file_list
    
    # 逐一刪除每個檔案
    for file_name in file_list:                       #對file_list進行遍歷
        file_path = os.path.join(directory, file_name)#將directory和file_name進行結合 
        # 判斷是否為檔案，若是則刪除
        if os.path.isfile(file_path):                 #若file_path是檔案
            os.remove(file_path)                      #刪除file_path
            print(f"{file_path} 已刪除")              #顯示已刪除

# def delete_directory(directory):              #下列三行為刪除資料夾，以便節省空間
#     os.rmdir(directory)
#     print(f"資料夾 {directory} 已刪除")

# 指定要刪除檔案的目錄路徑
directory_path = './uploads'  # 這裡假設 "uploads" 是要刪除檔案的目錄

# 呼叫函式刪除目錄中的檔案
delete_files_in_directory(directory_path)
     
# # 呼叫函式刪除目錄
# delete_directory(directory_path)                           