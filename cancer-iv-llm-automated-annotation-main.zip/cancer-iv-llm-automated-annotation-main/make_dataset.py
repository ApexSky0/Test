import os 
import json

from Xml_operator import Xml_operator


'''
starts : the start index of each line
ends : the end index of each line
lines : the content of each line
labels : [line][labels id][0>label 1>content]
    [
        [ [label, content],[label, content] ] # line 1
        [ [label, content],[label, content] ] # line 2
        [ [label, content],[label, content] ] # line 3
    ]
'''


def get_all_xml_path(dir):
    # get all xml files in the LABELED_DIR
    xml_files = []
    for root, dirs, files in os.walk(dir):
        for file in files:
            if file.endswith('.xml'):
                xml_files.append(os.path.join(root, file).replace('\\', '/') )
    print('xml_files len :', len(xml_files))
    return xml_files

def read_data_from_xml(xml_file):
    xml_op = Xml_operator(xml_file)
    text = xml_op.read_text()
    tags = xml_op.read_tags()
    
    starts = []
    ends = []
    lines = [s for s in text.split('\n') if s != '']
    labels = [[] for _ in range(len(lines))]

    # get the start and end index of each line
    now_index = 0
    for line in lines:
        st = text.find(line, now_index)
        en = st + len(line)
        starts.append(st)
        ends.append(en)
        now_index = en        
    
    # put the labels in the right line
    for tag in tags:
        label = tag['label']
        content = tag['text']
        spans = tag['spans'].split('~')
        spans = [int(s) for s in spans] # 0:start 1:end
        for i in range(len(lines)):
            if spans[0] >= starts[i] and spans[1] <= ends[i]:
                labels[i].append([label, content])
                break
    
    return starts, ends, lines, labels

def window_data(lines, labels, window_size):
    dataset_jsonl = []
    for i in range(len(lines)-window_size+1):
        content = '\n'.join(lines[i:i+window_size])
        
        label = []
        for j in range(i, i+window_size): # i ~ i+WINDOW_SIZE-1
            label.extend(labels[j])
        
        for j in range(len(label)): # label[j] = [label, content]
            label[j] = label[j][0] + ': ' + label[j][1]
        label = '\n'.join(label) # label = 'label1: content1\nlabel2: content2'
        
        label = 'NULL' if label == '' else label
        dataset_jsonl.append({'content': content, 'label': label})
    return dataset_jsonl


if __name__ == '__main__':
    LABELED_DIR = 'data/labeled'
    WINDOW_SIZE = 3
    
    
    xml_files = get_all_xml_path(LABELED_DIR)
    dataset_jsonl = []
    for xml_file in xml_files:
        starts, ends, lines, labels = read_data_from_xml(xml_file)
        win_jsonl = window_data(lines, labels, WINDOW_SIZE)
        dataset_jsonl.extend(win_jsonl)

    
        
    with open('./.output/dataset.jsonl' , 'w' , encoding='utf-8') as f:
        for item in dataset_jsonl:
            js = json.dumps(item , ensure_ascii=False)
            f.write(js + '\n')
            
                
                
                