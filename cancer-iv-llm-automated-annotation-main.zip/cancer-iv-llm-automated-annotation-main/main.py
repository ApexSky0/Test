

from make_dataset import get_all_xml_path, read_data_from_xml      #導入make_dataset.py文件中的get_all_xml_path, read_data_from_xml
from Xml_operator import Xml_operator                              #導入Xml_operator.py文件中的Xml_operator
from Model import Model                                            #導入Model.py文件中的Model
import os                                                          #導入os庫
from tqdm import tqdm                                              #導入tqdm庫中的tqdm

from Text_labeler import TextLabeler                               #導入Text_labeler庫中的TextLabeler

def main(path):                                                        #把main當成副程式，並設參數path
    UNLABEL_DIR = './data/unlabeled'                                   #設定UNLABEL_DIR為./data/unlabeled
    WINDOW_SIZE = 3                                                    #設定WINDOW_SIZE
    BATH_SIZE = 3                                                      #設定BATH_SIZE
    LABEL_TYPES = Xml_operator.LABEL_TYPES                             #設定LABEL_TYPES為Xml_operator.LABEL_TYPES
      
    # file_path = get_all_xml_path(UNLABEL_DIR)                          #取得UNLABEL_DIR中所有xml文件路徑
    # print('file_path len :', len(file_path))                           #輸出提示訊息

    model = Model()                                                    #創建Model對象

    # clear tqdm 
    # tqdm._instances.clear()                                            #清空tqdm
    # for path in tqdm(file_path , leave=False , desc='files' , position=0):    #對file_path進行for迴圈
    file_name = path.split('/')[-1]                                       #取得文件名

    xml_op = Xml_operator(path)                                           #創建Xml_operator對象
    
    text = xml_op.read_text()                                             #讀取xml文件中的文本
    lines = [s for s in text.split('\n') if s != '']                      #將文本進行分割
    lines_start_index = []                                                #創建lines_start_index為空列表
    # find the start index of the lines at the text
    nind = 0                                                              #設定nind為0
    for i in range(len(lines)):                                           #對lines進行for迴圈
        f = text.find(lines[i], nind)                                     #尋找lines[i]在text中的位置
        lines_start_index.append(f)                                       #將f添加到lines_start_index中
        nind = f + len(lines[i])                                          #更新nind
    

    
    # lines = text.split('\n')
    
    questions = []                                                        #創建questions為空列表
    answers = []                                                          #創建answers為空列表
    answers_vaild_area = [] # (start, end)                                #創建answers_vaild_area為空列表
    
    # overlap window
    # for i in range(len(lines)-WINDOW_SIZE+1):
    #     questions.append( '\n'.join(lines[i:i+WINDOW_SIZE]) )
    
    # not overlap window
    for i in range(0, len(lines), WINDOW_SIZE):                           #對range(0, len(lines), WINDOW_SIZE)進行for迴圈
        questions.append( '\n'.join(lines[i:i+WINDOW_SIZE]) )             #將lines[i:i+WINDOW_SIZE]進行拼接並添加到questions中

    
            
            
    model_in = model.make_model_input(questions)                          #將questions進行處理
    
    for i in tqdm(range(0, len(model_in), BATH_SIZE) , leave=False , desc=f'{file_name}' , position=1):   #range(0, len(model_in), BATH_SIZE)進行for迴圈
        model_out = model(model_in[i:i+BATH_SIZE])                                       #對model_in[i:i+BATH_SIZE]進行處理
        answers.extend(model_out)                                                        #將model_out添加到answers中
        for _ in range(len(model_out)):                                                  #對range(len(model_out))進行for迴圈
            st =  lines_start_index[i]                          
            en = lines_start_index[i+WINDOW_SIZE-1] + len(lines[i+WINDOW_SIZE-1])        #取得lines_start_index[i]和lines_start_index[i+WINDOW_SIZE-1] + len(lines[i+WINDOW_SIZE-1]) 
            answers_vaild_area.append((st, en))                                          #將(st, en)添加到answers_vaild_area中

            
    # textLabeler
    text_labeler = TextLabeler(text)                                                     #創建TextLabeler對象
    for i in range(len(answers)):                                                        #對range(len(answers))進行for迴圈
        label_line = [line for line in answers[i].split('\n') if line != '']             #將answers[i]進行分割
        for line in label_line:                                                          #對label_line進行for迴圈
            sp_index = line.find(': ')                                                   #尋找line中': '的位置
            if sp_index != -1 and line[:sp_index] in LABEL_TYPES:                        #若sp_index不等於-1且line[:sp_index]在LABEL_TYPES中
                lb = line[:sp_index].strip()                                             #取得line[:sp_index]並進行strip
                ct = line[sp_index+2:].strip()                                           #取得line[sp_index+2:]並進行strip
                text_labeler.add_label(lb, ct  , answers_vaild_area[i])                  #對text_labeler進行處理
    
    # print(text_labeler)
    
    text_labeler.remove_overlap()                                                        #對text_labeler進行處理
    # print(text_labeler)
    
    # save to xml 
    label_dict = text_labeler.get_label_dict()                                           #取得text_labeler中的label_dict
    for lb in label_dict:                                                                #對label_dict進行for迴圈
        xml_op.add_tag(lb['type'], f'{lb["start"]}~{lb["end"]}', lb['word'])             #對xml_op進行處理
        
    # save_flie_name = path.split('/')[-1].replace('.xml', '_labeled.xml')                 #取得文件名並進行替換 
    # os.makedirs(f'./.output/xml/{save_flie_name}', exist_ok=True)                        #創建./.output/xml文件夾
    
    file_name = path.split('/')[-1].replace('.xml', '_labeled.xml')
    # xml_op.save(f'./.output/xml/{save_flie_name}')                                       #將xml_op保存到./.output/xml/{save_flie_name}
    xml_op.save(file_name)                                       #將xml_op保存到./.output/xml/{save_flie_name}
    return file_name

                                                                    