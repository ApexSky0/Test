# structure of the xml file
'''
<PathologyReportAnalysis>
    <TEXT>
        <![CDATA[
            Content of the TEXT element...
        ]]>
    </TEXT>
    <TAGS>
        <CANCER_OF_PRIMARY_SITE id="C0" spans="106~143" text="Malignant neoplasm of ascending colon"  />
        <TNM_STAGE id="T0" spans="262~271" text="pT 1 N 1b"  />
    </TAGS>
</PathologyReportAnalysis>
'''

# import xml.etree.ElementTree as ET
# import xml.dom.minidom
# import xml.sax.saxutils as saxutils

import lxml.etree as ET                            #
from lxml.etree import CDATA

class Xml_operator:                                #xml檔案操作
    LABEL_TYPES = [                                #標籤類型
        'CANCER_OF_PRIMARY_SITE',                  #原發部位癌症
        'RECUR_FLAG',                              #復發標誌
        'RECUR_SITE',                              #復發部位
        'RECUR_EVIDENCE',                          #復發證據
        'TNM_STAGE',                               #TNM分期
        'OUTCOME_FLAG'                             #結果標誌
    ]
    LABEL_char = [                                 #標籤字元
        'C',                                       #原發部位癌症
        'R',                                       #復發標誌 
        'RE',                                      #復發部位
        'REC',                                     #復發證據
        'T',                                       #TNM分期
        'O', # not sure                            #結果標誌
    ]

    def __init__(self, xml_file):                  #初始化
        self.xml_file = xml_file                   #xml檔案
        
        self.tree = ET.parse(xml_file , ET.XMLParser(remove_blank_text=True))  #解析xml檔案
        self.root = self.tree.getroot()                                        #取得根節點

        # <![CDATA[{}]]> will be added to the text element
        self.write_text(self.read_text())          #寫入文字
 

        # add all LABEL_TYPES be zero in counter dict 
        self.type_counter = {}                     #標籤類型計數器
        for label in self.LABEL_TYPES:             #標籤類型
            self.type_counter[label] = 0           #標籤類型計數器

        # count the number of each label in the xml file
        for tag in self.root.find('TAGS'):         #尋找標籤
            for label in self.LABEL_TYPES:         #標籤類型
                if label in tag.tag:               #標籤類型
                    self.type_counter[label] += 1  #標籤類型計數器+1
            

    def read_text(self):                              #讀取文字
        return self.root.find('TEXT').text            #取得TEXT節點文字
    def write_text(self, content):                    #寫入文字
        self.root.find('TEXT').text = CDATA(content)  #寫入文字
    
    def read_tags(self):                              #讀取標籤
        tags = []                                     #標籤
        for tag in self.root.find('TAGS'):            #尋找標籤
            dic = {}                                  #字典
            dic['label'] = tag.tag                    #標籤
            dic.update(tag.attrib) # id spans text    #更新字典
            tags.append(dic)                          #加入標籤
        return tags                                   #回傳標籤
    
    def add_tag(self, label, spans, text):            #新增標籤，標籤類型，範圍，文字
        assert label in self.LABEL_TYPES, 'label not in LABEL_TYPES'                          #確認標籤類型在標籤類型中
        # update the counter #更新計數器
        id = self.LABEL_char[self.LABEL_TYPES.index(label)] + str(self.type_counter[label])   #標籤id 
        self.type_counter[label] += 1                 #標籤類型計數器+1

        tag = ET.Element(label)                       #標籤
        tag.set('id', id)                             #標籤id
        tag.set('spans', spans)                       #標籤範圍
        tag.set('text', text)                         #標籤文字
        self.root.find('TAGS').append(tag)            #加入標籤
     
    def save(self , path=None):                       #儲存
        if path == None:                              #如果路徑為空
            path = self.xml_file.split('.')[0] + '_labeled.xml'  #路徑為原檔案名稱_Labeled.xml
            
        # ET.indent(self.tree, '')
        self.tree.write(path, xml_declaration=True, encoding='utf-8', pretty_print=True)     #寫入檔案
        
        # s = ET.tostring(self.tree, xml_declaration=True, encoding='utf-8'  , pretty_print=True )
        # print(s.decode('utf-8'))


if __name__ == '__main__':                             #主程式
    # xml_file_path = 'data/labeled/44/44_2020-10-12.xml'  #xml檔案路徑
    xml_file_path = 'test.xml'                         #xml檔案路徑
    xml_op = Xml_operator(xml_file_path)               #xml檔案操作


    print(xml_op.read_text())                          #讀取文字
    # print(xml_op.read_tags())                        #讀取標籤
    for i in xml_op.read_tags():                       #讀取標籤
        print(i)                                       #印出標籤
 
    xml_op.add_tag('RECUR_SITE', '0~100', 'test')      #新增標籤
    xml_op.add_tag('OUTCOME_FLAG', '0~101', 'test')    #新增標籤
    xml_op.add_tag('RECUR_SITE', '0~102', 'test')      #新增標籤
    xml_op.add_tag('RECUR_SITE', '0~103', 'test')      #新增標籤
    xml_op.add_tag('RECUR_SITE', '0~104', 'test')      #新增標籤
    xml_op.add_tag('CANCER_OF_PRIMARY_SITE', '0~105', 'test')      #新增標籤
    xml_op.write_text('new content')                   #寫入文字

    xml_op.save(path='test_OUT.xml')                   #儲存



