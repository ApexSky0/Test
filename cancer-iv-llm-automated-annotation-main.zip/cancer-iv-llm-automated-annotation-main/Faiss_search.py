# from datasets import load_dataset, Features, Value
from sentence_transformers import SentenceTransformer   #導入SentenceTransformer，句子轉換成固定長度的數值向量，向量在語義上捕捉了句子的意義和上下文關係。
                                                                                      
import numpy as np                         #NumPy庫將其命名為np的數值計算庫，提供大量的多維數組操作和數學函數
from tqdm import tqdm                      #tqdm庫，可在迭代過程中顯示進度條
import faiss                               #faiss庫，用於高效相似性搜索和密集向量聚類
from  Dataset_reader import DatasetReader  #DatasetReader庫，用於讀取和管理數據集


# DATASET_PATH = rf"./.output/dataset.csv" 數據集文件的路徑.csv檔
FAISS_INDEX_PATH = './.output/faiss.index' #定義FAISS索引文件的路徑.index檔

def encode_sentence(txts):                 #定義encode_sentence，將文本轉換為向量
    sent_model = SentenceTransformer('all-mpnet-base-v2')      #用SentenceTransformer模型，將文本轉換為向量
    b_size = 1000                                              #定義批量大小為1000
    vector = []                                                #初始化向量
    total_size = len(txts)                                     #取得文本的總數
    if total_size == 1:                                        #如果只有一個句子，不顯示進度條，直接編碼
        vector.extend(sent_model.encode([txts[0]]))         
        return vector                                       
    for i in range(0, len(txts)+1, b_size): # tqdm(range(0, len(txts)+1, b_size))  #否則，按批處理大小分批進行編碼，顯示進度條
        e_index = i+b_size                                     #取得結束索引
        if e_index > total_size:                               #若結束索引大於文本總數，則取文本總數
            e_index = total_size                               #否則，取結束索引
        vector.extend(sent_model.encode(txts[i:e_index]))      #將編碼後的向量添加到向量列表中
    return vector

def faiss_search_make_index(texts):                            #定義faiss_search_make_index，創建faiss索引
    print("make index")                                        #輸出提示訊息
    vector = encode_sentence(texts)                            #將文本轉換為向量
    dim = vector[0].shape[0]                                   #取得向量的維度
    index = faiss.IndexFlatL2(dim)                             #創建一個L2距離的平面索引
    index.add(np.array(vector))                                #將向量添加到索引中
    faiss.write_index(index, FAISS_INDEX_PATH)                 #將索引寫入文件
    
def faiss_search_load_index():                                 #定義faiss_search_load_index，加載faiss索引
    print("load index")                                        #輸出提示訊息
    index = faiss.read_index(FAISS_INDEX_PATH)                 #讀取索引文件
    return index 

def faiss_search(index, query, return_top=5):                  #定義faiss_search，進行faiss搜索
    query_vector = None                                        #初始化查詢向量
    if type(query) == str:                                     #若查詢是字串，則轉換為向量
        query_vector = encode_sentence([query])                #將查詢轉換為向量
    else:
        query_vector = encode_sentence(query)                  #否則，將查詢列表轉換為向量
    D, I = index.search(np.array(query_vector), return_top)    #搜索最近的向量
    return I


if __name__ == "__main__":                                     #測試部分:創建DatasetReader對象並進行一些操作                       
    
    dataset = DatasetReader('./.output/dataset.jsonl')         #創建DatasetReader對象，讀取數據集
    faiss_search_make_index(dataset.get_all_contents())        #創建faiss索引
    index = faiss_search_load_index()                          #加載faiss索引
    print("index ntotal: ", index.ntotal)                      #輸出索引總數


    # querys = [r"The purpose of the study is for lesion detection.\n1) Consider sigmoid colon cancer with tumor invasion through visceral peritoneum and\nvisible metastatic lymphadenopathy in the adjacent mesenteric space."]
    querys = ['The purpose of the study' , 'The purpose of the study is for lesion detection.\n1) Consider sigmoid colon cancer with tumor invasion through visceral peritoneum and\nvisible metastatic lymphadenopathy in the adjacent mesent']
    query = "The purpose of the study is for lesion detection.\n1) Consider sigmoid colon cancer with tumor invasion through visceral peritoneum and\nvisible metastatic lymphadenopathy in the adjacent mesenteric space."
    querys = [
        query,
        'Mild fibrosis change of both lung apex.\nSpondylosis of the thoracolumbar spine.\nAtherosclerosis of the aorta.',
        '臨床診斷： Melena\n診斷代碼：\nIMMUNOHISTOCHEMICAL RESULTS',

    ]
    
    print(querys)                                              #輸出查詢
    res = faiss_search(index, query)                           #進行faiss搜索
    print(res)                                                 #輸出搜索結果
    print(dataset.get_content(res[0][0]))                      #輸出搜索結果內容
    print('-------------------')                               
    
    res = faiss_search(index, querys)                          #進行faiss搜索
    print(res)                                                 #輸出搜索結果
    for i in res:                                              #遍歷搜索結果
        print(dataset.get_content(i[1]))                       #輸出搜索結果內容
        print('--')                                            #輸出分隔線
    print('-------------------')                               #輸出分隔線
    
    

    