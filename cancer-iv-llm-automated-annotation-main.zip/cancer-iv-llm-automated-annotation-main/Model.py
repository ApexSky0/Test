from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers import pipeline
import torch
from Faiss_search import *
from Dataset_reader import DatasetReader

# from vllm import LLM, SamplingParams


class Model:                                         #定義Model類
    def __init__(self):                              #初始化
        self.dataset = DatasetReader('./.output/dataset.jsonl')
        
        self.index = faiss_search_load_index()
        print("index ntotal: ", self.index.ntotal)

        self.device = "cuda" 

        
        # batch 
        self.tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-Instruct-v0.2")
        self.model = AutoModelForCausalLM.from_pretrained("mistralai/Mistral-7B-Instruct-v0.2"  ,  torch_dtype=torch.float16 , device_map=self.device)
        
        # self.model = AutoModelForCausalLM.from_pretrained("mistralai/Mistral-7B-Instruct-v0.2")
        # self.tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-Instruct-v0.2" , token='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')
        self.tokenizer.pad_token = self.tokenizer.eos_token

        # pipeline 
        # self.pipe = pipeline("text-generation", model="mistralai/Mistral-7B-Instruct-v0.2" , torch_dtype=torch.float16 , device=self.device , max_new_tokens=100 , pad_token_id = self.tokenizer.eos_token_id)
        
        
        self.prompt = None
        with open('prompt.txt', 'r') as f:
            self.prompt = f.read()

        self.qa_template = "[IN]: {}\n[OUT]: {}\n"
        self.q_template = "[IN]: {}\n[OUT]:"

    def make_model_input(self, ques, exp=3):
        model_inputs = []
        search_res = faiss_search(self.index, ques, return_top=exp)
        for q_inx in range(len(ques)): # for each question
            content = []
            content.append(self.prompt)
            # print(search_res[q_inx])
            for i in range(exp):
                content.append(f'example {i}')
                p_index = search_res[q_inx][i]
                qa = self.qa_template.format(self.dataset.get_content(p_index), self.dataset.get_label(p_index))
                content.append(qa)
            content.append(f'Now is your turn')
            content.append(self.q_template.format(ques[q_inx]))
            content = '\n'.join(content)        

            messages = [
                {"role": "user", "content": content},
                # {"role": "assistant", "content": ""},
            ]

            chat = self.tokenizer.apply_chat_template(messages, tokenize=False)# return_tensors="pt"
            model_inputs.append(chat)
            
        return model_inputs
    
    #### batch
    # def __call__(self , input_texts , remove_prompt=True):
    #     tokens =  self.tokenizer(input_texts , return_tensors="pt" , padding=True , return_attention_mask=True) # device=self.device
    #     tokens.to(self.device)
    #     # print('tokens: ' , tokens)
        
    #     generated_ids = self.model.generate(**tokens, max_new_tokens=100, do_sample=False , pad_token_id=self.tokenizer.eos_token_id)
    #     decoded = self.tokenizer.batch_decode(generated_ids , skip_special_tokens=True)

    #     if remove_prompt:
    #         for i in range(len(input_texts)):
    #             kw = '[/INST] '
    #             new_word_index = decoded[i].rfind(kw) + len(kw)
    #             if new_word_index == -1:
    #                 print('ERROR not found')
                    
    #             decoded[i] = decoded[i][new_word_index:]
        
    #     return decoded
    
    
    
    # vllm
    def __call__(self , input_texts , remove_prompt=True):
        tokens =  self.tokenizer(input_texts , return_tensors="pt" , padding=True , return_attention_mask=True) # device=self.device
        tokens.to(self.device)
        # print('tokens: ' , tokens)
        
        generated_ids = self.model.generate(**tokens, max_new_tokens=100, do_sample=False , pad_token_id=self.tokenizer.eos_token_id)
        decoded = self.tokenizer.batch_decode(generated_ids , skip_special_tokens=True)

        if remove_prompt:
            for i in range(len(input_texts)):
                kw = '[/INST] '
                new_word_index = decoded[i].rfind(kw) + len(kw)
                if new_word_index == -1:
                    print('ERROR not found')
                    
                decoded[i] = decoded[i][new_word_index:]
        
        return decoded
    
    
    ##### pipeline 
    # def __call__(self , input_texts):
    #     res = []
    #     for  t in input_texts:
    #         r = self.pipe(input_texts)
    #         res.append(r[0])
    #     print(res)
    #     return res 

    
if __name__ == "__main__":
    model = Model()
    
    # ques = [
    #     'The purpose of the study is for lesion detection.\n1) Consider sigmoid colon',
    #     'invasion through visceral peritoneum and',
    #     'visible metastatic lymphadenopathy in the adjacent mesenteric space.'
    # ]
    
    # ques = [
    #     'this is question 1 content',
    #     'this is question 2 content',
    #     'this is question 3 content',
    #     'this is question 4 content'
    # ]
    
    ques = [
        '''組織名稱： COLON\n臨床診斷： Advanced colon cancer; sigmoid colon; post bx\n診斷代碼： (M-8140/3)''',
        '''Atherosclerosis of aorta.\nSpondylosis and mild scoliosis of thoracolumbar spine.\nConsider pneumoperitoneum. DDx: post operation related.''',
        '''The bony thorax remains unremarkable.\nThe bowel gas reveals prominent.\nThe air-fluid levels are noted at the abdomen.''',
        
        '''組織名稱： Colon; NOS\n臨床診斷： - Advanced colon cancer was found on 20cm from anal verge. Perform biopsy x5\n診斷代碼： (M-8140/3)'''
        
    
    ]
    
    # ques =[
    #     '''組織名稱： Colon; NOS\n臨床診斷： - Advanced colon cancer was found on 20cm from anal verge. Perform biopsy x5\n診斷代碼： (M-8140/3)'''
    # ]
    
    model_in = model.make_model_input(ques)
    
    with open('./.output/test_model_input.txt', 'w' , encoding='utf-8') as f:
        for i in range(len(model_in)):
            f.write(f'<prompt {i}>\n')
            f.write(model_in[i])
            f.write('\n<end>\n')
            
            
    model_out =  model(model_in)
    
    with open('./.output/test_model_output.txt', 'w' , encoding='utf-8') as f:
        for i in range(len(model_out)):
            f.write(f'<question {i}>\n')
            f.write(ques[i])
            f.write('\n')
            
            f.write(f'<output {i}>\n')
            f.write(model_out[i])
            f.write('\n<end>\n')

        
        
        