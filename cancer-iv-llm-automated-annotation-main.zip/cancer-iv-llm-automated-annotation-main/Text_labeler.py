from typing import Any, List, Tuple                                       




class Label:                                       
    def __init__(self, type, word, start, end):     #定義標籤類，用於表示文本中的標籤
        self.type = type                            #標籤類型
        self.word = word                            #標籤內容
        self.start = start                          #標籤起始位置
        self.end = end                              #標籤結束位置
        
        if end-start != len(word):                  #若標籤的(結束位置)-(起始位置)不等於標籤長度，則輸出提示訊息
            print(f'[Label] word {word} length not equal to end-start')  #提示訊息

    def __str__(self):                                                  #定義__str__方法，返回標籤的字符串顯示
        # return f'{self.type}: {self.word}'
        return f"<Label: type={self.type}, start={self.start}, end={self.end}, content='{self.word}'>"  #返回標籤的字符串顯示


    def __repr__(self):                                                 #定義__repr__方法，返回標籤的字符串顯示                                         
        # return f'{self.type}: {self.word}<{self.start}~{self.end}>'
        return f"<Label: type={self.type}, start={self.start}, end={self.end}, content='{self.word}'>"  #返回標籤的字符串顯示
    
        
        
    
    #def __eq__(self, other):
    #    return self.type == other.type and self.word == other.word
    #def __ne__(self, other):
    #    return not self.__eq__(other)

    def get_index(self):                                               #定義get_index方法
        return self.start, self.end                                    #返回標籤的起始位置和結束位置
    def get_type(self):                                                #定義get_type方法
        return self.type                                               #返回標籤的類型
    def get_word(self):                                                #定義get_word的方法
        return self.word                                               #返回標籤的內容
    def get_start(self):                                               #定義get_start的方法
        return self.start                                              #返回標籤的起始位置
    def get_end(self):                                                 #定義get_end的方法
        return self.end                                                #返回標籤的結束位置
    
    @staticmethod                                                          #定義is_overlap方法
    def is_overlap(label1, label2):                                        #判斷兩個標籤是否重疊
        return label1.start <= label2.end and label2.start <= label1.end      
    #若標籤1的起始位置小於等於標籤2的結束位置且標籤2的起始位置小於等於標籤1的結束位置，則返回True，否則返回False
        

class TextLabeler:                                                     #定義TextLabeler類
    def __init__(self, text):                                          #初始化
        self.text = text                                               #文本
        self.label: List[Label] = []                                   #標籤列表
   
    def __repr__(self):                                                #定義__repr__方法
        s = '\n'.join(map(str , self.label))                           #將標籤列表轉換為字符串
        return f'{self.text}\n{s}\n'                                   #返回文本和標籤列表的字符串顯示
    
    def get_label_dict(self):                                          #定義get_label_dict方法
        res = []                                                       #返回值
        for i in self.label:                                           #遍歷標籤列表
            dic = {                                                    #字典
                'type': i.get_type(),                                  #標籤類型
                'word': i.get_word(),                                  #標籤內容
                'start': i.get_start(),                                #標籤起始位置
                'end': i.get_end()                                     #標籤結束位置
            }               
            res.append(dic)                                            #加入字典
        return res                                                     #返回字典
     
    
    def add_label(self, type, word, search_range=None): # add all matched word #新增標籤
        vaild_text = self.text                                         #有效文本    
        offset = 0                                                     #偏移量
    
        if search_range:                                               #若有搜尋範圍
            vaild_text = self.text[search_range[0]:search_range[1]]    #取得有效文本
            offset = search_range[0]                                   #取得偏移量

        # check if any word in vaild_text
        if vaild_text.find(word)==-1 or len(word)==0:                  #若有效文本中沒有標籤或標籤長度為0
            # print(f'[TextLabeler] word {word} not found in vaild_text')
            return                                                     #返回
        
        now_index = 0 # valid_text index                               #有效文本索引
        while True:                                                    #無限循環
            start = vaild_text.find(word, now_index)                   #取得標籤的起始位置
            if start == -1:                                            #若起始位置為-1
                break                                                  #跳出循環
            self.label.append(Label(type, word, start+offset, start+len(word)+offset))   #加入標籤
            now_index = start + 1                                      #更新索引

    def remove_overlap(self): # remove overlap label from tail         #移除重疊標籤
        nlb : List[Label] = []                                         #新標籤列表
        for lb in self.label:                                          #遍歷標籤列表
            is_overlap = False                                         #是否重疊
            for n in nlb:                                              #遍歷新標籤列表
                if Label.is_overlap(lb, n):                            #若標籤重疊
                    is_overlap = True                                  #設置為重疊
                    break                                              #跳出循環
            if not is_overlap:                                         #若不重疊
                nlb.append(lb)                                         #加入新標籤列表
        self.label = nlb                                               #更新標籤列表
                
            
        
    
if __name__ == '__main__':                                                       #主程式
    text = "a bb ccc dddd eeeee ffffff ggggggg hhhhhhhh iiiiiiiii jjjjjjjjjj"    #文本
    text_labeler = TextLabeler(text)                                             #TextLabeler類
         
    text_labeler.add_label('typegg', 'gg' , search_range=(29, 32))               #新增標籤
    text_labeler.add_label('type1', 'bb')                                        #新增標籤
    text_labeler.add_label('type2', 'ccc')                                       #新增標籤
    text_labeler.add_label('type2', 'ccc')                                       #新增標籤
    text_labeler.add_label('type2', 'cc')                                        #新增標籤
    text_labeler.add_label('type2', 'cc')                                        #新增標籤
    text_labeler.add_label('type3', 'dddd')                                      #新增標籤
    
    print(text_labeler)                                                          #輸出TextLabeler類
    
    print('remove overlap')                                                      #輸出提示訊息
    
    text_labeler.remove_overlap()                                                #移除重疊標籤
    print(text_labeler)                                                          #輸出TextLabeler類